#include <Servo.h>
#include "Arduino.h"

#ifndef Humanoide_h
#define Humanoide_h

class Humanoide {

//Public Members..
public:
	//Contructor...
	Humanoide();
	//Public Methods...
	void init(int legRightPin, int legLeftPin);
	void aheadWalk();
	void backWalk();
	void stopWalk();

//Private Members...
private:
	Servo legRight;
	Servo legLeft;

};

#endif