#include "Humanoide.h"

Humanoide::Humanoide()
{
}

void Humanoide::init(int legRightPin, int legLeftPin)
{
	this->legRight.attach(legRightPin);
	this->legLeft.attach(legLeftPin);
	this->legRight.write(90);
	this->legLeft.write(90);
}

void Humanoide::aheadWalk(){

	this->legRight.write(150);
	this->legLeft.write(150);
	delay(2000);
	this->legLeft.write(30);
	this->legRight.write(30);
	delay(2000);
}