package org.schmitt.framework.serial.controller;

public class InitController {
	
	public static void main(String...strings)
	{
		new ControllerFrame();
	}
	
}
